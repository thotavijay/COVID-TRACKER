export default {
  purple: "#6236FF",
  red: "#F9345E",
  green: "#1CB142",
  orange: "#FA6400",
  darkPurple: "#1A1053",
  lightPurple: "#817C9B",
};

//  purple: rgb(98, 54, 255);
//  red: rgb(249, 52, 94);
//  green: rgb(28, 177, 66);
//  orange: rgb(250, 100, 0);
//  darkPurple: rgb(26, 16, 83);
//  lightPurple: rgb(129, 124, 155);
