export default {
  container: {
    backgroundColor: "rgba(129, 124, 155, 0.05)",
    padding: "3rem",
    borderRadius: "2.5rem",
    width: "100%",
  }
}