import React, { Component } from "react";
import { Link } from "react-router-dom";
import { withStyles } from "@material-ui/styles";



import styles from "../styles/SymptomsStyles";

class Symptoms extends Component {
  render() {
    const { classes } = this.props;
    return (
      <div className={classes.symptoms}>
        <h2 className={classes.heading}>
          <span>COVID-19 Coronavirus</span> - Symptoms
        </h2>
        <div className={classes.content}>
          <div className={classes.mainContent}>
            <div className={classes.alert}>
              <p>
              Multiple COVID-19 vaccines that are available in the market, including the Covishield, Covaxin, and Sputnik V vaccines that have been approved for usage in India, currently consist of two doses.
              </p>
            </div>
            <div className={classes.symptomsMain}>
              <p>
                On average it takes 5–6 days from when someone is infected with
                the virus for symptoms to show, however it can take up to 14
                days. People with mild symptoms who are otherwise healthy should
                self-isolate. Seek medical attention if you have a fever, a
                cough, and difficulty breathing.
              </p>
            </div>
            <div className={classes.symptomsDiv}>
              <p>
                COVID-19 affects different people in different ways. Most
                infected people will develop mild to moderate symptoms.
              </p>
              <h5 className={classes.symptomsHeading}>Common symptoms</h5>
              <ul className={classes.sympList}>
                <li>fever.</li>
                <li>tiredness.</li>
                <li>dry cough.</li>
              </ul>
              <h5 className={classes.symptomsHeading}>
                Some people may experience
              </h5>
              <ul className={classes.sympList}>
                <li>aches and pains.</li>
                <li>nasal congestion.</li>
                <li>runny</li>
                <li>nose.</li>
                <li>sore throat.</li>
                <li>diarrhoea.</li>
              </ul>
            </div>
            <small className={classes.info}>
              
            </small>
          </div>
         
        </div>
        
      </div>
    );
  }
}

export default withStyles(styles)(Symptoms);
